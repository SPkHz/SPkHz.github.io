%---------------------------------------------
%EE 332 Lab #05 Mosfet BPF
%---------------------------------------------

clear
clc
close all

%---------------------------------------------

k = 10^+3;
m = 10^-3;
u = 10^-6;
n = 10^-9;
NF= 32;

%-------------------------------------------------

Folder_Main=...
    'C:\Users\bryam\Desktop\EE-322-02 Elec Engin Lab II\Lab 05';
Folder_LTspice=...
    [Folder_Main, '\LTspice'];

%--------------------------------------------------

File_LTspice_LF='EE 322 Lab 05  Try 3.raw';
File_Loc_LTspice_LF=...
    [Folder_LTspice,'\', File_LTspice_LF];
File_LTspice_Bode= 'EE 322 Lab 05  Try 3.raw';
File_Loc_LTspice_Bode=...
    [Folder_LTspice,'\', File_LTspice_Bode];
%---------------------------------------------------------

[freq_LTspice, Av_f_LTspice, Av_f_LTspice_Mag,...
    Av_f_LTspice_dB, Av_f_LTspice_Ang,~]...
    =Read_LTspice_Bode(File_Loc_LTspice_Bode,'vo');
[fL_LTspice, f0_LTspice, fH_LTspice,...
    BW_f_LTspice, Q_LTspice]=...
    BPF_Param_LTspice(freq_LTspice,Av_f_LTspice_Mag);
Av_f0_LTspice=...
    Av_f_LTspice(Av_f_LTspice_Mag==...
    max(Av_f_LTspice_Mag));
I_sign= sign(real(Av_f0_LTspice));
Av_mid_LTspice= I_sign*abs(Av_f0_LTspice);
Av_mid_LTspice_Mag=abs(Av_mid_LTspice);
Av_mid_LTspice_dB=...
    20*log10(Av_mid_LTspice_Mag);
%---------------------------------------------------------

fx_LTspice=...
    [fL_LTspice, f0_LTspice, fH_LTspice];
[Av_fL_LTspice]=...
    Find_Interpolated_Value(freq_LTspice,...
    Av_f_LTspice, fL_LTspice);
[Av_fH_LTspice]=...
    Find_Interpolated_Value(freq_LTspice,...
    Av_f_LTspice, fH_LTspice);
Av_fx_LTspice=[Av_fL_LTspice,...
    Av_f0_LTspice, Av_fH_LTspice];
[Av_fx_LTspice_Mag, Av_fx_LTspice_Ang]=...
    Rect_2_Polar(Av_fx_LTspice);
Av_fx_LTspice_dB=...
    20*log10(Av_fx_LTspice_Mag);

%---------------------------------------------------------
%data = readtable('C:\Users\bryam\Desktop\EE-322-02 Elec Engin Lab II\Lab 05\Measured\Bode and Phase.CSV');
data = readtable('C:\Users\bryam\Desktop\EE-322-02 Elec Engin Lab II\Lab 05\Measured\WFM02.CSV');
%disp(data.Properties.VariableNames);
frequency = data.("FrequencyInHz"); % Frequency in Hz
gain_dB = data.("GainInDB");        % Gain in dB
phase_deg = data.("PhaseIn_");      % Phase in degrees

%---------------------------------------------------------

IFigure=0;
IFigure= IFigure+1;
figure_max(IFigure)
plot( freq_LTspice, Av_f_LTspice_dB, 'r', 'LineWidth',9)
hold on
plot(frequency,gain_dB,'g','LineWidth',10)
plot( fx_LTspice, Av_fx_LTspice_dB,'ko','LineWidth', 13)
%plot(Hz_interp,GT_measured_spline,'b','LineWidth',10)
hold off
grid on
grid minor
axis([10, 10^6, 0, 12]);
set(gca, 'xscale', 'log')
set(gca, 'xtick', logspace(1, 6, 6)); 
set(gca, 'ytick', (0: 3 : 12 ));
legend(...
 'Simulated',...
 'Measured',...
 '',...
 'location', 'best')
xlabel('{\it{f}} (Hz) ')
ylabel('| {\it{Gv( f )}}| ( dB ) ',...
 'VerticalAlignment', 'bottom')
set(gca, 'linewidth', 2)
set(gca, 'FontName', 'times new roman', 'FontSize', NF)
%-----------------------------------------------------
IFigure= IFigure+1;
figure_max(IFigure)
plot(freq_LTspice, Av_f_LTspice_Ang, 'r', 'LineWidth',9)
hold on
plot(frequency, phase_deg, 'r', 'LineWidth',9)
plot( fx_LTspice, Av_fx_LTspice_Ang,'ko','LineWidth', 13)

hold off
grid on
grid minor
axis([10, 10^5, -180, 180]);
set(gca, 'xscale', 'log')
set(gca, 'xtick', logspace(1, 5, 5)); 
set(gca, 'ytick', (-180: 45 : 180 ));
legend(...
 'Simulated',...
 'Measured',...
 '',...
 'location', 'best')
xlabel('{\it{f}} (Hz) ')
ylabel(' {\it{θ }} ( ° ) ',...
 'VerticalAlignment', 'bottom')
set(gca, 'linewidth', 2)
set(gca, 'FontName', 'times new roman', 'FontSize', NF)

%-----------------------------------------------------


Print_Real_Unit('fx_LTspice', fx_LTspice,'Hz')
Print_Real_Unit('BW_f_LTspice', BW_f_LTspice,'Hz')
Print_Real_Unit('Q_LTspice', Q_LTspice,'Hz/Hz')
Print_Real_Unit('Av_mid_LTspice', Av_mid_LTspice,'V/V')
Print_Real_Unit('Av_mid_LTspice_dB', Av_mid_LTspice_dB,'dB')



















