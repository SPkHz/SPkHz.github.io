%% EE470 Project 01 - Continuous to Discrete Servo Model Transformation
% c2d_SL_CallV01 - Organized Version
%clc; clear; close all;

%% ----- Sampling Time and Final Time -----
% s_time = 1/100;     % Sampling time (100 Hz)
% f_time = 0.5;       % Final simulation time (seconds)
% PO = 0.01;        % Percent Overshoot
% Tp = 0.05;        % Peak Time (seconds)

fprintf('Sampling time = %7.5f \n', s_time);

%% ----- Continuous-Time System Definition -----
A = [0 1; 0 -48.27];
B = [0; 6776.29];
C = [5/(9.7*pi) 0; 0 (1.5*60)/(1000*2*pi)];
D = [0; 0];

% Continuous-time state-space model
sysc = ss(A, B, C, D);
disp('--- Continuous-time State-Space Model (Part I) ---');
sysc

%% ----- Discrete-Time Conversion -----
sysd = c2d(sysc, s_time);
disp('--- Discrete-time State-Space Model (Part II) ---');

[Ad, Bd, Cd, Dd] = ssdata(sysd);
[numd, dend] = tfdata(sysd);

% Display discrete matrices
a11 = Ad(1,1); a12 = Ad(1,2);
a21 = Ad(2,1); a22 = Ad(2,2);
b1  = Bd(1,1); b2  = Bd(2,1);

fprintf('a11 = %12.9f    a12 = %12.9f\n', a11, a12);
fprintf('a21 = %12.9f    a22 = %12.9f\n', a21, a22);
fprintf('b1  = %12.9f\n', b1);
fprintf('b2  = %12.9f\n\n', b2);

%% ----- Discrete Transfer Function and Poles -----
numd1 = numd{1};
dend1 = dend{1};

fprintf('--- Discrete Transfer Function Coefficients ---\n');
fprintf('Discrete numerator ='); fprintf(' %7.5f', numd1); fprintf('\n');
fprintf('Discrete denominator ='); fprintf(' %7.5f', dend1); fprintf('\n');

fprintf('Discrete poles ='); fprintf(' %7.5f', roots(dend1)); fprintf('\n');

%% ----- Partial Fraction Expansion -----
[coef, poles, rem] = residue(numd1, dend1);

disp('--- Partial Fraction Expansion ---');
disp('Residue coefficients:'); disp(coef);
disp('Poles of the system:'); disp(poles);
disp('Remainder term:'); disp(rem);

%% ----- Design Specifications (PO and Tp) -----

% Calculate continuous desired poles
M = log(PO/100);
zeta = -M / sqrt(pi^2 + M^2);
beta = sqrt(1 - zeta^2);
wn = pi / (Tp * beta);
den = [1 2*zeta*wn wn^2];
poles_c = roots(den);

% Convert to discrete poles
poles_d = exp(poles_c * s_time);

%% ----- Sampling Frequency and Time Vector -----
s_freq = 1/s_time;

disp('Sampling frequency requirement:'); disp(s_freq);

t = 0:s_time:f_time;

%% ----- Specification Calculation for Plotting -----
print_flag = 0;
if ~exist('PO', 'var')
    PO = 0.01;
    Tp = 0.07;
    print_flag = 1;
end

M = (log(PO))^2;
zeta_d = sqrt(M / (M + pi^2));
beta_d = sqrt(1 - zeta_d^2);
wn_d = pi / (Tp * beta_d);

if print_flag == 1
    clc;
    fprintf('Cal_Zeta_Wn results \n');
    fprintf('Desired wn_d and zeta_d \n');
    fprintf('zeta_d= %7.2f  wn_d = %7.2f \n', zeta_d, wn_d);
end

%% ----- Design Parameters and Plot Annotations -----
figure(1);
plot(0,0,10,10);
hold on;
text(1,9,'Design parameters');
fprintf('Design parameters\n');
fprintf('PO =  %6.3f  TP = %6.3f\n', PO, Tp);
text(1,8.5,['PO = ', num2str(PO), ' TP = ', num2str(Tp)]);

fprintf('Calculated values\n');
text(1,8,'Calculated values');
fprintf('zeta =  %6.3f    beta = %6.3f\n', zeta_d, beta_d);
fprintf('wn =  %6.3f\n', wn_d);
text(1,7.5,['\zeta = ', num2str(zeta_d), ' \omega_n = ', num2str(wn_d)]);
hold off;

%% ----- Update for Controller Design -----
wn = wn_d;
zeta = zeta_d;
den = [1 2*zeta*wn wn^2];

% Confirm desired poles
poles_c = roots(den)
poles_d = exp(poles_c * s_time)

%% ----- Controller Design: State and Output Feedback -----
if ~exist('a', 'var')
    a = [0 1; 0 -48.27];
    b = [0; 6776.29];
    c = [5/(9.7*pi) 0; 0 (1.5*60)/(1000*2*pi)];
    d = [0; 0];
end

% Rebuild system
sysc = ss(a,b,c,d);
systfc = tf(sysc, 'v');

sysd = c2d(sysc, s_time);
[numd, dend] = tfdata(sysd, 'v');
[ad, bd, cdm, dd] = ssdata(sysd);

% Feedback gain design
disp('**** Feedback Gain Design ****');
disp('State feedback gains (K)');
K = acker(ad, bd, poles_d)

K1 = K(1,1);
K2 = K(1,2);

disp('Output feedback gains (G)');
G = K * inv(c);
G1 = G(1,1);
G2 = G(1,2);

% Closed-loop system
adc = ad - bd * K;

disp('Closed-loop discrete A matrix (Adc)');
adc

disp('Closed-loop eigenvalues');
eig(adc)

% Create closed-loop systems
sysd_c = ss(adc, bd, cdm, dd, s_time);
sysc_c = d2c(sysd_c);
sysc_ctf = tf(sysc_c, 'v');

% Step response plot
n = s_freq * t(end) + 1;
td = 0:s_time:f_time;
[ydc, time, xdc] = step(sysd_c, t);

figure(2);
plot(td, xdc(:,1), 'LineWidth', 2);
grid on;
grid minor;

xlabel('Time (seconds)', 'FontSize', 12);
ylabel('Position (units)', 'FontSize', 12);
title('Step Response - Discrete Servo Design', 'FontSize', 14);
set(gca, 'FontSize', 12);
ylim([0 1.2]);
box on;

ax_p = axis;
tx = ax_p(2) * 0.4;
ty = ax_p(4) * 0.5;
systxt = 'sys Cont';

% Display performance specs on figure
Cal_PerSpecsFnc(sysc_ctf(1,1), systxt, tx, ty, 0);

fprintf('K1 = %6.3f   K2 = %6.3f\n', K1, K2);
fprintf('G1 = %6.3f   G2 = %6.3f\n', G1, G2);

% Add title with G gains
hold on;
txt01 = num2str(G1, '%6.3f');
txt02 = num2str(G2, '%6.3f');
title(['G1 = ', txt01, '   G2 = ', txt02]);
hold off;
