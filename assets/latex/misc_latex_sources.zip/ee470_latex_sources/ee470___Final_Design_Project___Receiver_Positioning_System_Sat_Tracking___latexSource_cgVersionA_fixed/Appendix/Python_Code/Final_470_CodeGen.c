/*
 * Final_470_CodeGen.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Final_470_CodeGen".
 *
 * Model version              : 10.7
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C source code generated on : Sun Apr 27 09:10:02 2025
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#include "Final_470_CodeGen.h"
#include "rtwtypes.h"
#include "Final_470_CodeGen_private.h"

/* Block signals (default storage) */
B_Final_470_CodeGen_T Final_470_CodeGen_B;

/* Continuous states */
X_Final_470_CodeGen_T Final_470_CodeGen_X;

/* Disabled State Vector */
XDis_Final_470_CodeGen_T Final_470_CodeGen_XDis;

/* Real-time model */
static RT_MODEL_Final_470_CodeGen_T Final_470_CodeGen_M_;
RT_MODEL_Final_470_CodeGen_T *const Final_470_CodeGen_M = &Final_470_CodeGen_M_;
static void rate_scheduler(void);

/*
 *         This function updates active task flag for each subrate.
 *         The function is called at model base rate, hence the
 *         generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (Final_470_CodeGen_M->Timing.TaskCounters.TID[2])++;
  if ((Final_470_CodeGen_M->Timing.TaskCounters.TID[2]) > 9) {/* Sample time: [0.01s, 0.0s] */
    Final_470_CodeGen_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Final_470_CodeGen_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  Final_470_CodeGen_step();
  Final_470_CodeGen_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  Final_470_CodeGen_step();
  Final_470_CodeGen_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void Final_470_CodeGen_step(void)
{
  int32_T rtb_Step;
  if (rtmIsMajorTimeStep(Final_470_CodeGen_M)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&Final_470_CodeGen_M->solverInfo,
                          ((Final_470_CodeGen_M->Timing.clockTick0+1)*
      Final_470_CodeGen_M->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Final_470_CodeGen_M)) {
    Final_470_CodeGen_M->Timing.t[0] = rtsiGetT(&Final_470_CodeGen_M->solverInfo);
  }

  /* Step: '<Root>/Step' */
  rtb_Step = !(Final_470_CodeGen_M->Timing.t[0] < 0.1);

  /* Sum: '<S1>/Sum3' incorporates:
   *  Gain: '<S1>/gear1'
   *  Gain: '<S1>/gear3'
   *  Gain: '<S1>/math pot1'
   *  Integrator: '<S1>/Int2'
   *  Integrator: '<S1>/Int3'
   *  Sum: '<S1>/Sum2'
   */
