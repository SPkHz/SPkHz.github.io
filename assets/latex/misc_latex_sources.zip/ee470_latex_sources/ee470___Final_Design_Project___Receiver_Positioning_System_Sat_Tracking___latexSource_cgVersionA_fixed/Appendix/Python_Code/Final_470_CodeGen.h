
/*
 * Final_470_CodeGen.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Final_470_CodeGen".
 *
 * Model version              : 10.7
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C source code generated on : Sun Apr 27 09:10:02 2025
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef Final_470_CodeGen_h_
#define Final_470_CodeGen_h_
#ifndef Final_470_CodeGen_COMMON_INCLUDES_
#define Final_470_CodeGen_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* Final_470_CodeGen_COMMON_INCLUDES_ */

#include "Final_470_CodeGen_types.h"
#include <string.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Sum3;                         /* '<S1>/Sum3' */
  real_T gear2;                        /* '<S1>/gear2' */
  real_T Sum1;                         /* '<S2>/Sum1' */
  real_T ZeroPole;                     /* '<S2>/Zero-Pole' */
} B_Final_470_CodeGen_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Int2_CSTATE;                  /* '<S1>/Int2' */
  real_T Int3_CSTATE;                  /* '<S1>/Int3' */
  real_T Int1_CSTATE;                  /* '<S2>/Int1' */
  real_T ZeroPole_CSTATE;              /* '<S2>/Zero-Pole' */
} X_Final_470_CodeGen_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Int2_CSTATE;                  /* '<S1>/Int2' */
  real_T Int3_CSTATE;                  /* '<S1>/Int3' */
  real_T Int1_CSTATE;                  /* '<S2>/Int1' */
  real_T ZeroPole_CSTATE;              /* '<S2>/Zero-Pole' */
} XDot_Final_470_CodeGen_T;

/* State disabled  */
typedef struct {
  boolean_T Int2_CSTATE;               /* '<S1>/Int2' */
  boolean_T Int3_CSTATE;               /* '<S1>/Int3' */
  boolean_T Int1_CSTATE;               /* '<S2>/Int1' */
  boolean_T ZeroPole_CSTATE;           /* '<S2>/Zero-Pole' */
} XDis_Final_470_CodeGen_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Real-time Model Data Structure */
struct tag_RTM_Final_470_CodeGen_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_Final_470_CodeGen_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_Final_470_CodeGen_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[4];
  real_T odeF[3][4];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint8_T TID[3];
    } TaskCounters;

    time_T tStart;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[3];
  } Timing;
};

/* Block signals (default storage) */
extern B_Final_470_CodeGen_T Final_470_CodeGen_B;

/* Continuous states (default storage) */
extern X_Final_470_CodeGen_T Final_470_CodeGen_X;

/* Disabled states (default storage) */
extern XDis_Final_470_CodeGen_T Final_470_CodeGen_XDis;

/* Model entry point functions */
extern void Final_470_CodeGen_initialize(void);
extern void Final_470_CodeGen_step(void);
extern void Final_470_CodeGen_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Final_470_CodeGen_T *const Final_470_CodeGen_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/G1' : Unused code path elimination
 * Block '<Root>/G2' : Unused code path elimination
 * Block '<Root>/S1' : Unused code path elimination
 * Block '<Root>/S2' : Unused code path elimination
 * Block '<Root>/Scope 1' : Unused code path elimination
 * Block '<Root>/Scope 2' : Unused code path elimination
 * Block '<Root>/Sum4' : Unused code path elimination
 * Block '<Root>/T' : Unused code path elimination
 * Block '<Root>/T1' : Unused code path elimination
 * Block '<Root>/a11' : Unused code path elimination
 * Block '<Root>/a12' : Unused code path elimination
 * Block '<Root>/a22' : Unused code path elimination
 * Block '<Root>/b1' : Unused code path elimination
 * Block '<Root>/b2' : Unused code path elimination
 * Block '<Root>/b3' : Unused code path elimination
 * Block '<Root>/math gear' : Unused code path elimination
 * Block '<Root>/math pot2' : Unused code path elimination
 * Block '<Root>/rad//s to V' : Unused code path elimination
 * Block '<S1>/amp1' : Eliminated nontunable gain of 1
 * Block '<S2>/amp' : Eliminated nontunable gain of 1
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Final_470_CodeGen'
 * '<S1>'   : 'Final_470_CodeGen/Continuous SS'
 * '<S2>'   : 'Final_470_CodeGen/Continuous System Transfer function '
 */
#endif                                 /* Final_470_CodeGen_h_ */