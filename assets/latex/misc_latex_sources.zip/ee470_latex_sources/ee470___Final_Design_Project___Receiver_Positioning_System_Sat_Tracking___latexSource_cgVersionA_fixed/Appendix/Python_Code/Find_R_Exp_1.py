from ltspice import Ltspice
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Path to the LTspice .raw file (ensure this is correct)
raw_file = r"C:\Users\bryam\Desktop\EE-322-02 Elec Engin Lab II\Lab 05\LTspice\EE 322 Lab 05 Exp 1 Vo DC.raw"

# Load the .raw file
ltspice_data = Ltspice(raw_file)
ltspice_data.parse()  # Process the file

# Display available variables in the file
print("Available variables in the file:")
for var in ltspice_data.variables:
    print(var)

# Try extracting resistance ('r') and current ('I(R)')
try:
    resistances = ltspice_data.get_data('r')  # Use 'r' instead of 'param'
    currents = ltspice_data.get_data('I(R)') * 1e6  # Convert to µA
except KeyError as e:
    print(f"⚠️ Error extracting data: {e}")
    resistances = []
    currents = []

# Verify if the data was extracted successfully
if resistances is not None and currents is not None and len(resistances) > 0 and len(currents) > 0:
    print(f"Extracted resistances: {resistances[:5]} ...")  # Show first 5 values
    print(f" Extracted currents: {currents[:5]} µA ...")

    # Create a DataFrame and save data to CSV
    data = pd.DataFrame({'Resistance (Ohm)': resistances, 'Current I(R) (µA)': currents})
    data.to_csv('Results_R_vs_IR.csv', index=False)
    print("✅ Data exported to 'Results_R_vs_IR.csv'.")

    # Plot I(R) vs R
    plt.figure(figsize=(8, 6))
    plt.plot(resistances, currents, marker='o', linestyle='-', color='b', label="I(R) vs R")
    plt.axhline(y=500, color='r', linestyle='--', label="500 µA")
    plt.xlabel("Resistance R (Ohm)", fontsize=12)
    plt.ylabel("Current I(R) (µA)", fontsize=12)
    plt.title("Current vs Resistance Curve", fontsize=14)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.show()

    # 🔍 Find R where I(R) ≈ 500 µA
    target_current = 500  # µA
    diff = np.abs(currents - target_current)
    index = np.argmin(diff)  # Index of the closest value

    # Extract the optimal resistance
    optimal_resistance = resistances[index]
    optimal_current = currents[index]

    print(f"🎯 The closest resistance to I(R) = 500 µA is R = {optimal_resistance:.2f} Ohm with I(R) = {optimal_current:.2f} µA")

    # Mark the point on the plot
    plt.figure(figsize=(8, 6))
    plt.plot(resistances, currents, marker='o', linestyle='-', color='b', label='I(R) vs R')
    plt.scatter(optimal_resistance, optimal_current, color='r', 
                label=f'I(R) ≈ {optimal_current:.2f} µA at R={optimal_resistance:.2f} Ω', zorder=3)
    plt.xlabel('Resistance R (Ohms)', fontsize=12)
    plt.ylabel('Current I(R) (µA)', fontsize=12)
    plt.title('Current vs Resistance', fontsize=14)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(fontsize=10)
    plt.show()
else:
    print("❌ No data found for plotting. Check variable names in LTspice.")
